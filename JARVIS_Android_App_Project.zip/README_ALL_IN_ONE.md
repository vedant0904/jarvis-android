# J.A.R.V.I.S. Android — Unified Alarm, Calls & Conversation Patch

This ZIP contains the Android Studio project and GitHub Actions workflow.

## Included changes
- Native Android alarm/reminder scheduling through AlarmManager (subject to Android exact-alarm permission and notification settings).
- Alarm command patterns such as “set an alarm in 2 minutes” and “set an alarm for 6:30 PM”.
- Phone calls: say “call” plus a phone number, or say “call” and select a contact from Android Contacts. JARVIS opens the dialer for you to review and tap Call; it does not silently place calls.
- Basic local conversational replies for greetings, feelings, advice prompts, jokes, and common questions.
- Existing music search, gallery, settings, app launch, voice input/output, and reminder features retained.

## Important limitations
The conversational improvements are local scripted replies, not a connected general-purpose AI model. Full open-ended smart conversation requires an AI service/backend connection. Android alarm behavior depends on exact-alarm permission and the notification channel's sound settings. Contact calling requires an installed contacts picker and dialer; users review and confirm every call.

## Build using GitHub Actions
1. Upload this ZIP to your repository root named exactly `JARVIS_Android_App_Project.zip` (keep the root project folder inside the ZIP).
2. Keep `.github/workflows/build-jarvis-apk.yml` in the repository.
3. Open Actions → Build JARVIS debug APK → Run workflow.
4. Download the `JARVIS-debug-APK` artifact and extract it to get `app-debug.apk`.
