package com.vedant.jarvis;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 501;
    private static final int PHOTO_REQUEST = 502;
    private WebView webView;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private String pendingSpeech = null;
    private float pendingRate = 1.0f;
    private float pendingPitch = 1.0f;
    private String pendingLanguage = "en-IN";
    private Uri selectedPhoto;
    private final Set<String> scheduledKeys = new HashSet<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int languageResult = textToSpeech.setLanguage(new Locale("en", "IN"));
                ttsReady = languageResult != TextToSpeech.LANG_MISSING_DATA && languageResult != TextToSpeech.LANG_NOT_SUPPORTED;
                if (!ttsReady) ttsReady = textToSpeech.setLanguage(Locale.UK) >= TextToSpeech.LANG_AVAILABLE;
                if (ttsReady && pendingSpeech != null) {
                    String queued = pendingSpeech; float rate = pendingRate; float pitch = pendingPitch; String language = pendingLanguage;
                    pendingSpeech = null; speakNative(queued, rate, pitch, language);
                }
            }
        });
        getWindow().setStatusBarColor(android.graphics.Color.rgb(2,7,16));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(2,7,16));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true); s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme()) || "about".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean dialog, boolean userGesture, android.os.Message resultMsg) {
                WebView child = new WebView(MainActivity.this);
                child.setWebViewClient(new WebViewClient() {
                    @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, req.getUrl())); } catch (Exception ignored) { }
                        v.destroy(); return true;
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(child); resultMsg.sendToTarget(); return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 700);
    }

    private void js(String function, String value) {
        if (webView == null) return;
        String quoted = JSONObject.quote(value == null ? "" : value);
        runOnUiThread(() -> webView.evaluateJavascript("if(window." + function + "){window." + function + "(" + quoted + ");}", null));
    }

    public class AndroidBridge {
        @JavascriptInterface public void speakText(String text, float rate, float pitch, String language) {
            runOnUiThread(() -> {
                pendingSpeech = text == null ? "" : text;
                pendingRate = Math.max(0.5f, Math.min(2.0f, rate));
                pendingPitch = Math.max(0.5f, Math.min(2.0f, pitch));
                pendingLanguage = language == null ? "en-IN" : language;
                if (ttsReady) {
                    String queued = pendingSpeech; pendingSpeech = null;
                    speakNative(queued, pendingRate, pendingPitch, pendingLanguage);
                } else {
                    Toast.makeText(MainActivity.this, "JARVIS voice is initializing. Try again in a moment.", Toast.LENGTH_SHORT).show();
                }
            });
        }
        @JavascriptInterface public void stopSpeech() {
            runOnUiThread(() -> { if (textToSpeech != null) textToSpeech.stop(); });
        }
        @JavascriptInterface public void startVoiceRecognition() {
            runOnUiThread(() -> {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a JARVIS command");
                try { startActivityForResult(i, VOICE_REQUEST); }
                catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "Voice input service is not available", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void openGallery() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
                try { startActivityForResult(i, PHOTO_REQUEST); } catch (Exception e) { Toast.makeText(MainActivity.this, "Photo picker unavailable", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void openDialer(String number) {
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number == null ? "" : number)))); } catch (Exception ignored) { } });
        }
        @JavascriptInterface public void openApp(String app) {
            runOnUiThread(() -> launchApp(app));
        }
        @JavascriptInterface public void connectBluetooth() {
            runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); } catch (Exception ignored) { } });
        }
        @JavascriptInterface public void searchMusic(String query, String provider) {
            runOnUiThread(() -> {
                String q = query == null ? "" : query.trim();
                String p = provider == null ? "youtube music" : provider.toLowerCase(Locale.ROOT).trim();
                if (q.isEmpty()) { Toast.makeText(MainActivity.this, "Say a song name first", Toast.LENGTH_SHORT).show(); return; }
                String url;
                if (p.equals("spotify")) {
                    url = "https://open.spotify.com/search/" + Uri.encode(q);
                } else if (p.equals("youtube") || p.equals("youtube music") || p.equals("music")) {
                    url = "https://music.youtube.com/search?q=" + Uri.encode(q);
                } else {
                    url = "https://music.youtube.com/search?q=" + Uri.encode(q);
                }
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))); }
                    catch (Exception ignored) { Toast.makeText(MainActivity.this, "Could not open music search", Toast.LENGTH_SHORT).show(); }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not open music search", Toast.LENGTH_SHORT).show();
                }
            });
        }
        @JavascriptInterface public void musicControl(String action) {
            runOnUiThread(() -> {
                int key = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
                if ("pause".equalsIgnoreCase(action)) key = KeyEvent.KEYCODE_MEDIA_PAUSE;
                else if ("play".equalsIgnoreCase(action)) key = KeyEvent.KEYCODE_MEDIA_PLAY;
                else if ("next".equalsIgnoreCase(action)) key = KeyEvent.KEYCODE_MEDIA_NEXT;
                else if ("previous".equalsIgnoreCase(action)) key = KeyEvent.KEYCODE_MEDIA_PREVIOUS;
                AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
                if (am != null) { am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, key)); am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, key)); }
            });
        }
        @JavascriptInterface public void scheduleReminder(String text, double at) {
            runOnUiThread(() -> scheduleOne(text, (long)at));
        }
        @JavascriptInterface public void cancelAllReminders() {
            runOnUiThread(() -> cancelReminders());
        }
    }

    private void speakNative(String text, float rate, float pitch, String language) {
        if (textToSpeech == null || !ttsReady || text == null || text.trim().isEmpty()) return;
        try {
            Locale locale = Locale.forLanguageTag(language == null || language.isEmpty() ? "en-IN" : language);
            int result = textToSpeech.setLanguage(locale);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech.setLanguage(new Locale("en", "IN"));
            }
            textToSpeech.setSpeechRate(Math.max(0.5f, Math.min(2.0f, rate)));
            textToSpeech.setPitch(Math.max(0.5f, Math.min(2.0f, pitch)));
            if (Build.VERSION.SDK_INT >= 21) textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-" + System.currentTimeMillis());
            else textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        } catch (Exception e) {
            Toast.makeText(this, "JARVIS could not start speech output.", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchApp(String app) {
        String a = app == null ? "" : app.toLowerCase(Locale.ROOT).trim();
        String pkg = null;
        if (a.equals("echomusic") || a.equals("echo music") || a.equals("echomusicapp")) pkg = "echo.music.iad1tya";
        else if (a.equals("youtube")) pkg = "com.google.android.youtube";
        else if (a.equals("spotify")) pkg = "com.spotify.music";
        else if (a.equals("instagram")) pkg = "com.instagram.android";
        else if (a.equals("whatsapp")) pkg = "com.whatsapp";
        else if (a.equals("google")) pkg = "com.google.android.googlequicksearchbox";
        try {
            if (pkg != null) { Intent launch = getPackageManager().getLaunchIntentForPackage(pkg); if (launch != null) { startActivity(launch); return; } }
            String url = a.equals("echomusic") || a.equals("echo music") || a.equals("echomusicapp") ? "https://www.youtube.com/results?search_query=Echo+Music" :
                a.equals("spotify") ? "https://open.spotify.com" : a.equals("instagram") ? "https://www.instagram.com" :
                a.equals("whatsapp") ? "https://www.whatsapp.com" : a.equals("github") ? "https://github.com" :
                a.equals("google") ? "https://www.google.com" : "https://www.youtube.com";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) { Toast.makeText(this, "Could not open " + app + ". Check that it is installed.", Toast.LENGTH_LONG).show(); }
    }

    private void scheduleOne(String text, long at) {
        if (at <= System.currentTimeMillis()) return;
        String key = Integer.toString((text + at).hashCode());
        Intent i = new Intent(this, ReminderReceiver.class).putExtra("text", text).putExtra("key", key);
        PendingIntent pi = PendingIntent.getBroadcast(this, key.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarm = (AlarmManager)getSystemService(ALARM_SERVICE);
        if (alarm != null) { if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); else alarm.set(AlarmManager.RTC_WAKEUP, at, pi); }
        SharedPreferences p = getSharedPreferences("jarvis", MODE_PRIVATE);
        Set<String> keys = new HashSet<>(p.getStringSet("reminder_keys", new HashSet<>())); keys.add(key); p.edit().putStringSet("reminder_keys", keys).apply();
    }
    private void cancelReminders() {
        AlarmManager alarm = (AlarmManager)getSystemService(ALARM_SERVICE); SharedPreferences p = getSharedPreferences("jarvis", MODE_PRIVATE);
        for (String key : p.getStringSet("reminder_keys", new HashSet<>())) {
            Intent i = new Intent(this, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(this, key.hashCode(), i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null && alarm != null) { alarm.cancel(pi); pi.cancel(); }
        }
        p.edit().remove("reminder_keys").apply();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) js("jarvisVoiceResult", results.get(0));
        } else if (requestCode == PHOTO_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedPhoto = data.getData(); try { getContentResolver().takePersistableUriPermission(selectedPhoto, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (SecurityException ignored) { }
            js("jarvisGallerySelected", selectedPhoto.toString());
        }
    }
    @Override protected void onDestroy() {
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; }
        if (webView != null) { webView.removeJavascriptInterface("Android"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
