# J.A.R.V.I.S. — Complete Android Project Bundle

This bundle includes the Android source project and a GitHub Actions workflow template. It is source code, not a prebuilt APK.

## Features included in this project
- Futuristic JARVIS HUD and local command/chat logic
- Native Android text-to-speech output
- Android speech-recognition handoff
- Native reminders/alarms via Android AlarmManager and reminder notifications (timing may be deferred by Android)
- Open supported apps/web destinations (YouTube, Spotify, Instagram, WhatsApp, Google; Echo Music launch is best-effort)
- Music search via YouTube Music and Spotify
- Media controls: play, pause, next, previous (depends on Android routing and the active player's media session)
- Open photo picker/gallery
- Open phone dialer with a number for the user to review and confirm
- Open Bluetooth settings (pairing remains user-controlled)
- Local command history and simple personalization stored by the browser HUD

## Build through GitHub Actions on a phone
1. Upload the folder `JARVIS_Android_App_Project` contents as a ZIP named exactly `JARVIS_Android_App_Project.zip` to the root of your GitHub repository `jarvis-android`.
2. Keep the repository workflow at `.github/workflows/build-jarvis-apk.yml`. The copy included here is in `github-workflow/build-jarvis-apk.yml` as a reference; GitHub only runs workflow files stored in the repository's `.github/workflows/` directory.
3. Open the repository's **Actions** tab, select **Build JARVIS debug APK**, then choose **Run workflow**.
4. When it succeeds, open the run and download the `JARVIS-debug-APK` artifact. Extract it and install `app-debug.apk` on your phone.

## Important limitations (please read)
- This is a source project, not a compiled APK. It has not been built or device-tested in this environment.
- Echo Music's package ID (`echo.music.iad1tya`) is a best-effort guess. If it is wrong, app launch may fall back to a web search. No verified Echo Music-specific song-search deep link is implemented here, so JARVIS may open Echo Music but you may need to search inside it manually.
- Music search is implemented for YouTube Music and Spotify. Direct automatic playback is not guaranteed; choose a result in the music app if needed.
- Play/pause/next/previous send Android media-key events. These work only if Android routes them to an active media session.
- Reminder/alarm delivery depends on Android permissions, battery restrictions, and OS scheduling. Exact-minute delivery is not guaranteed; check notification permission and system alarm settings if a reminder does not arrive.
- Phone calls open the dialer for confirmation; the app does not silently place calls.
- Bluetooth opens system settings; Android pairing and permissions remain under your control.
- “Smarter JARVIS” in this bundle means the local command engine and scripted responses. It is not connected to a live AI model/backend, cannot access every phone setting, and cannot perform unrestricted actions in the background. An AI backend/API and more native integrations would be needed for those capabilities.
- Android intentionally restricts actions such as reading private app data, silently calling contacts, and changing some protected settings. JARVIS cannot bypass those restrictions.
