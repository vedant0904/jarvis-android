plugins { id("com.android.application") }

android {
    namespace = "com.vedant.jarvis"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vedant.jarvis"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
