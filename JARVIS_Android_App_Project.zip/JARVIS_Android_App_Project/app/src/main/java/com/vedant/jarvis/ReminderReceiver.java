package com.vedant.jarvis;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String text = intent.getStringExtra("text");
        if (text == null || text.trim().isEmpty()) text = "Your JARVIS alarm is due.";
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        final String channelId = "jarvis_alarm_alerts_v2";
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alarmSound == null) alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(channelId, "JARVIS alarms and reminders", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Sound alerts for scheduled JARVIS alarms and reminders");
            channel.setSound(alarmSound, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            manager.createNotificationChannel(channel);
        }
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new android.app.Notification.Builder(context, channelId)
            : new android.app.Notification.Builder(context).setSound(alarmSound);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
         .setContentTitle("J.A.R.V.I.S. alarm")
         .setContentText(text)
         .setCategory(android.app.Notification.CATEGORY_ALARM)
         .setPriority(android.app.Notification.PRIORITY_MAX)
         .setAutoCancel(true);
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
