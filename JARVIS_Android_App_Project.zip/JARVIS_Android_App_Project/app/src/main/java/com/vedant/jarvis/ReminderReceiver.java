package com.vedant.jarvis;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String text = intent.getStringExtra("text"); if (text == null || text.trim().isEmpty()) text = "Your JARVIS reminder is due.";
        NotificationManager manager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(new NotificationChannel("jarvis_reminders", "JARVIS reminders", NotificationManager.IMPORTANCE_HIGH));
        android.app.Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) b = new android.app.Notification.Builder(context, "jarvis_reminders"); else b = new android.app.Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("J.A.R.V.I.S. reminder").setContentText(text).setAutoCancel(true);
        manager.notify((int)(System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
