# J.A.R.V.I.S. Android App Project

This is the Android Studio source project wrapping the existing JARVIS HUD in a native Android WebView. It is source code, not a prebuilt APK.

## Build the APK
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Open this folder (`JARVIS_Android_App_Project`) in Android Studio.
3. Let Gradle sync and install any requested build components.
4. Choose **Build > Build APK(s)**. The debug APK will be under `app/build/outputs/apk/debug/`.
5. Transfer the APK to your Android phone and install it. Android may ask you to allow installs from that source.

## Included
- Existing futuristic JARVIS HTML HUD and local command engine
- Native Android speech recognition handoff
- Android photo picker handoff
- Dialer launch (user confirms the call)
- App launch attempts for Echo Music, YouTube, Spotify, Instagram, WhatsApp and Google
- Media key events for play/pause/next/previous (depends on the active media app and Android version)
- Reminder notifications scheduled through Android AlarmManager (Android may defer inexact alarms)
- Bluetooth settings shortcut (pairing must be confirmed in Android settings)

## Important limitations
- Echo Music package ID in this project is a best-effort guess (`echo.music.iad1tya`). If that differs from the installed app, JARVIS falls back to a web search; change the package ID in `MainActivity.java` after checking the installed app's package name. The app does not expose a documented public song-search deep link in this project.
- Media keys only work when Android routes them to an active media session; app-specific controls are not guaranteed.
- General AI chat/emotional support is a local scripted prototype, not a connected AI service.
- Alarms use Android's inexact idle-friendly scheduler, so they are not guaranteed to fire at an exact minute.
- Calls open the dialer for user confirmation; this app does not silently place calls.
- Bluetooth opens system settings; Android pairing and permissions remain user-controlled.
- The project has not been compiled in this environment because Android SDK/Gradle are not installed here.


## Voice music search
- Say `play [song name]` or `play [song name] on YouTube Music` to open a YouTube Music search.
- Say `play [song name] on Spotify` to open Spotify search. The target app may open directly if installed and Android handles its links; otherwise a browser may open.
- Say `pause music`, `resume music`, `next song`, or `previous song` to send Android media-key events. Whether these work depends on the active player and Android version.
- JARVIS cannot guarantee automatic playback or bypass subscription/ad prompts; select a result in the music app when needed.
